import React from 'react';
import { TreeState } from '../types';

interface UIProps {
  currentState: TreeState;
  onToggle: () => void;
}

export const UI: React.FC<UIProps> = ({ currentState, onToggle }) => {
  const isTree = currentState === TreeState.TREE_SHAPE;

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-8 z-10">
      {/* Header */}
      <header className="flex flex-col items-center animate-fade-in-down">
        <h1 className="font-serif text-4xl md:text-6xl text-transparent bg-clip-text bg-gradient-to-b from-arix-gold to-[#8B6508] tracking-widest uppercase drop-shadow-lg">
          Arix Signature
        </h1>
        <p className="text-arix-gold/60 text-sm tracking-[0.3em] mt-2 font-light">
          HOLIDAY COLLECTION 2024
        </p>
      </header>

      {/* Footer / Controls */}
      <div className="flex flex-col items-center pb-8 pointer-events-auto">
        <button
          onClick={onToggle}
          className={`
            group relative px-8 py-4 bg-black/40 backdrop-blur-md 
            border border-arix-gold/30 rounded-full 
            transition-all duration-700 ease-out
            hover:bg-arix-gold/10 hover:border-arix-gold
            ${isTree ? 'w-64' : 'w-48'}
          `}
        >
           <span className="absolute inset-0 rounded-full border border-arix-gold/0 group-hover:border-arix-gold/50 scale-110 opacity-0 group-hover:opacity-100 transition-all duration-500"></span>
           
           <div className="flex items-center justify-center space-x-3">
             <span className={`w-2 h-2 rounded-full transition-colors duration-500 ${isTree ? 'bg-arix-gold shadow-[0_0_10px_#D4AF37]' : 'bg-gray-500'}`}></span>
             <span className="font-serif text-arix-gold tracking-widest text-lg">
                {isTree ? 'DISASSEMBLE' : 'ASSEMBLE'}
             </span>
           </div>
        </button>
        
        <p className="mt-4 text-xs text-white/20 font-mono tracking-wider">
          INTERACTIVE 3D EXPERIENCE
        </p>
      </div>
    </div>
  );
};
