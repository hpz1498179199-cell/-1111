import React, { useMemo, useRef, useLayoutEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { TreeState, ParticleData } from '../types';
import { TREE_CONFIG, COLORS, ANIMATION_SPEED } from '../constants';

interface ArixParticlesProps {
  state: TreeState;
}

const tempObject = new THREE.Object3D();
const tempVec3 = new THREE.Vector3();
const tempQuat = new THREE.Quaternion();

// Helper to generate random points in a cone
const getRandomPointInCone = (height: number, radius: number) => {
  const y = Math.random() * height; // Height from bottom (0 to height)
  // Inverse relationship: higher y = smaller radius
  // We lift the tree up so y=0 is centered vertically
  const relativeY = y - height / 2;
  
  const rAtHeight = radius * (1 - y / height);
  const r = Math.sqrt(Math.random()) * rAtHeight; // Sqrt for uniform distribution
  const theta = Math.random() * Math.PI * 2;
  
  const x = r * Math.cos(theta);
  const z = r * Math.sin(theta);
  
  return new THREE.Vector3(x, relativeY, z);
};

// Helper to generate random points in sphere
const getRandomPointInSphere = (radius: number) => {
  const u = Math.random();
  const v = Math.random();
  const theta = 2 * Math.PI * u;
  const phi = Math.acos(2 * v - 1);
  const r = Math.cbrt(Math.random()) * radius;
  const sinPhi = Math.sin(phi);
  const x = r * sinPhi * Math.cos(theta);
  const y = r * sinPhi * Math.sin(theta);
  const z = r * Math.cos(phi);
  return new THREE.Vector3(x, y, z);
};

export const ArixParticles: React.FC<ArixParticlesProps> = ({ state }) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const ornamentRef = useRef<THREE.InstancedMesh>(null);

  // Generate Data for Needles
  const needleData = useMemo(() => {
    const data: ParticleData[] = [];
    for (let i = 0; i < TREE_CONFIG.PARTICLE_COUNT; i++) {
      const treePos = getRandomPointInCone(TREE_CONFIG.HEIGHT, TREE_CONFIG.RADIUS_BASE);
      const scatterPos = getRandomPointInSphere(TREE_CONFIG.SCATTER_RADIUS);
      
      // Needles point somewhat outwards and upwards
      const lookAtTarget = new THREE.Vector3(treePos.x * 2, treePos.y + 2, treePos.z * 2);
      const treeRot = new THREE.Euler().setFromQuaternion(
        new THREE.Quaternion().setFromUnitVectors(
          new THREE.Vector3(0, 1, 0),
          lookAtTarget.sub(treePos).normalize()
        )
      );

      data.push({
        treePosition: treePos,
        treeRotation: treeRot,
        scatterPosition: scatterPos,
        scatterRotation: new THREE.Euler(Math.random() * Math.PI, Math.random() * Math.PI, 0),
        scale: 0.1 + Math.random() * 0.3,
        color: Math.random() > 0.5 ? COLORS.NEEDLE_1 : COLORS.NEEDLE_2,
        type: 'NEEDLE'
      });
    }
    return data;
  }, []);

  // Generate Data for Ornaments
  const ornamentData = useMemo(() => {
    const data: ParticleData[] = [];
    for (let i = 0; i < TREE_CONFIG.ORNAMENT_COUNT; i++) {
        // Place ornaments more on the surface
        const y = Math.random() * TREE_CONFIG.HEIGHT;
        const relativeY = y - TREE_CONFIG.HEIGHT / 2;
        const rAtHeight = TREE_CONFIG.RADIUS_BASE * (1 - y / TREE_CONFIG.HEIGHT);
        // Biased towards outer edge
        const r = (0.8 + Math.random() * 0.4) * rAtHeight; 
        const theta = Math.random() * Math.PI * 2;
        const x = r * Math.cos(theta);
        const z = r * Math.sin(theta);
        const treePos = new THREE.Vector3(x, relativeY, z);

        const scatterPos = getRandomPointInSphere(TREE_CONFIG.SCATTER_RADIUS * 1.2);

        data.push({
            treePosition: treePos,
            treeRotation: new THREE.Euler(0, 0, 0),
            scatterPosition: scatterPos,
            scatterRotation: new THREE.Euler(Math.random() * Math.PI, Math.random() * Math.PI, 0),
            scale: 0.3 + Math.random() * 0.4,
            color: Math.random() > 0.3 ? COLORS.GOLD : COLORS.ROSE_GOLD,
            type: 'ORNAMENT'
        });
    }
    return data;
  }, []);

  // Current animation progress (0 = scattered, 1 = tree)
  const progress = useRef(0);

  useLayoutEffect(() => {
    // Set initial colors
    if (meshRef.current) {
        needleData.forEach((d, i) => {
            meshRef.current!.setColorAt(i, d.color);
        });
        meshRef.current.instanceColor!.needsUpdate = true;
    }
    if (ornamentRef.current) {
        ornamentData.forEach((d, i) => {
            ornamentRef.current!.setColorAt(i, d.color);
        });
        ornamentRef.current.instanceColor!.needsUpdate = true;
    }
  }, [needleData, ornamentData]);


  useFrame((stateObj, delta) => {
    // 1. Calculate Target Progress
    const target = state === TreeState.TREE_SHAPE ? 1 : 0;
    
    // 2. Smoothly interpolate progress using dampening
    const step = delta * ANIMATION_SPEED;
    if (Math.abs(progress.current - target) > 0.001) {
        progress.current = THREE.MathUtils.lerp(progress.current, target, step);
    }

    const t = progress.current;
    // Ease out elastic for a nice "snap" effect or SmoothStep
    const easedT = THREE.MathUtils.smoothstep(t, 0, 1);

    // 3. Update Needles
    if (meshRef.current) {
        needleData.forEach((data, i) => {
            // Position Lerp
            tempVec3.lerpVectors(data.scatterPosition, data.treePosition, easedT);
            
            // Rotation Lerp (Tricky with Euler, better to use Quaternions if strictly needed, but simple Euler lerp often suffices for chaos -> order)
            // Let's use logic: Scatter has random rotation, Tree has specific.
            // Actually, simply rotating the object continuously in scatter mode looks better
            
            tempObject.position.copy(tempVec3);
            
            // Dynamic Rotation Logic
            if (t < 0.9) {
                // Spin while scattered
                tempObject.rotation.set(
                    data.scatterRotation.x + stateObj.clock.elapsedTime * 0.5,
                    data.scatterRotation.y + stateObj.clock.elapsedTime * 0.2,
                    data.scatterRotation.z
                );
            } else {
                // Snap to tree rotation
                tempObject.rotation.set(
                    THREE.MathUtils.lerp(tempObject.rotation.x, data.treeRotation.x, step),
                    THREE.MathUtils.lerp(tempObject.rotation.y, data.treeRotation.y, step),
                    THREE.MathUtils.lerp(tempObject.rotation.z, data.treeRotation.z, step),
                );
            }

            tempObject.scale.setScalar(data.scale * (0.5 + 0.5 * easedT)); // Grow slightly as they assemble
            tempObject.updateMatrix();
            meshRef.current!.setMatrixAt(i, tempObject.matrix);
        });
        meshRef.current.instanceMatrix.needsUpdate = true;
    }

    // 4. Update Ornaments
    if (ornamentRef.current) {
        ornamentData.forEach((data, i) => {
             // Add some noise/delay to ornaments for visual variety
            const delay = (i % 10) * 0.02;
            const localT = THREE.MathUtils.clamp((t - delay) * 1.2, 0, 1);
            const localEasedT = THREE.MathUtils.smoothstep(localT, 0, 1);

            tempVec3.lerpVectors(data.scatterPosition, data.treePosition, localEasedT);
            tempObject.position.copy(tempVec3);
            
            // Ornaments just float gently
            tempObject.rotation.set(
                Math.sin(stateObj.clock.elapsedTime + i) * 0.1,
                stateObj.clock.elapsedTime * 0.2,
                Math.cos(stateObj.clock.elapsedTime + i) * 0.1
            );
            
            tempObject.scale.setScalar(data.scale * localEasedT); // Pop in when forming tree
            tempObject.updateMatrix();
            ornamentRef.current!.setMatrixAt(i, tempObject.matrix);
        });
        ornamentRef.current.instanceMatrix.needsUpdate = true;
    }
  });

  return (
    <>
        {/* Needles - Using a simple Tetrahedron for "sharp" leafy look that reflects light well */}
        <instancedMesh ref={meshRef} args={[undefined, undefined, TREE_CONFIG.PARTICLE_COUNT]} castShadow receiveShadow>
            <tetrahedronGeometry args={[1, 0]} />
            <meshStandardMaterial 
                roughness={0.6} 
                metalness={0.1} 
                flatShading={true}
            />
        </instancedMesh>

        {/* Ornaments - High gloss spheres */}
        <instancedMesh ref={ornamentRef} args={[undefined, undefined, TREE_CONFIG.ORNAMENT_COUNT]} castShadow receiveShadow>
            <sphereGeometry args={[1, 16, 16]} />
            <meshStandardMaterial 
                roughness={0.1} 
                metalness={0.9} 
                envMapIntensity={2}
            />
        </instancedMesh>
    </>
  );
};
