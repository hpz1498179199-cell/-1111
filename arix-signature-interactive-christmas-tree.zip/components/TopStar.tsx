import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { TreeState } from '../types';
import { COLORS, TREE_CONFIG, ANIMATION_SPEED } from '../constants';
import { Sparkles } from '@react-three/drei';

interface TopStarProps {
  state: TreeState;
}

export const TopStar: React.FC<TopStarProps> = ({ state }) => {
  const groupRef = useRef<THREE.Group>(null);
  const progress = useRef(0);
  
  // Position Logic
  const treePos = new THREE.Vector3(0, TREE_CONFIG.HEIGHT / 2 + 0.5, 0);
  const scatterPos = new THREE.Vector3(0, 20, -10); // Start high up

  useFrame((stateObj, delta) => {
    const target = state === TreeState.TREE_SHAPE ? 1 : 0;
    const step = delta * ANIMATION_SPEED;
    
    // Interpolate
    progress.current = THREE.MathUtils.lerp(progress.current, target, step * 0.8); // Slightly slower than tree
    const t = THREE.MathUtils.smoothstep(progress.current, 0, 1);

    if (groupRef.current) {
        // Position
        groupRef.current.position.lerpVectors(scatterPos, treePos, t);
        
        // Scale - appear only when forming
        const s = t * 1.5;
        groupRef.current.scale.setScalar(s);
        
        // Rotation - spin faster when assembling, slow gentle spin when done
        const spinSpeed = (1 - t) * 5 + 0.5; 
        groupRef.current.rotation.y += delta * spinSpeed;
    }
  });

  return (
    <group ref={groupRef}>
      {/* Central Core */}
      <mesh castShadow>
        <octahedronGeometry args={[1, 0]} />
        <meshStandardMaterial 
            color={COLORS.GOLD} 
            emissive={COLORS.GOLD}
            emissiveIntensity={2}
            toneMapped={false}
        />
      </mesh>
      
      {/* Outer Glow Halo */}
      <mesh scale={[2, 2, 2]}>
         <sphereGeometry args={[1, 16, 16]} />
         <meshBasicMaterial color={COLORS.GOLD} transparent opacity={0.1} />
      </mesh>

      {/* Sparkles specific to the star */}
      <Sparkles count={20} scale={4} size={4} speed={0.4} opacity={0.5} color="#FFF" />
    </group>
  );
};
