import React, { useRef, useState, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Environment, Stars, Float, ContactShadows } from '@react-three/drei';
import { EffectComposer, Bloom, Vignette, Noise } from '@react-three/postprocessing';
import { BlendFunction } from 'postprocessing';
import * as THREE from 'three';
import { ArixParticles } from './ArixParticles';
import { TopStar } from './TopStar';
import { TreeState } from '../types';

interface SceneProps {
  treeState: TreeState;
}

const MovingLight = () => {
    const lightRef = useRef<THREE.PointLight>(null);
    useFrame(({ clock }) => {
        if (lightRef.current) {
            const t = clock.elapsedTime * 0.5;
            lightRef.current.position.x = Math.sin(t) * 10;
            lightRef.current.position.z = Math.cos(t) * 10;
            lightRef.current.position.y = Math.sin(t * 2) * 2;
        }
    });
    return <pointLight ref={lightRef} intensity={50} distance={40} color="#ffaa00" decay={2} />;
};

export const Scene: React.FC<SceneProps> = ({ treeState }) => {
  return (
    <Canvas shadows dpr={[1, 2]} gl={{ antialias: false }}>
      {/* Camera Setup */}
      <PerspectiveCamera makeDefault position={[0, 2, 20]} fov={50} />
      <OrbitControls 
        enablePan={false} 
        minPolarAngle={Math.PI / 2.5} 
        maxPolarAngle={Math.PI / 1.8}
        minDistance={10}
        maxDistance={30}
        autoRotate={treeState === TreeState.TREE_SHAPE}
        autoRotateSpeed={0.5}
      />

      {/* Lighting - Cinematic & Dramatic */}
      <ambientLight intensity={0.2} />
      <spotLight 
        position={[10, 20, 10]} 
        angle={0.5} 
        penumbra={1} 
        intensity={200} 
        castShadow 
        color="#ffffff"
      />
      <spotLight 
        position={[-10, 5, -10]} 
        angle={0.5} 
        penumbra={1} 
        intensity={100} 
        color="#00ff88" // Emerald backlight
      />
      <MovingLight />

      {/* Environment */}
      <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
      <Environment preset="city" />
      
      {/* Floor Shadows */}
      <ContactShadows resolution={1024} scale={50} blur={2} opacity={0.5} far={10} color="#000000" />

      {/* The Main Actor: The Tree */}
      <group position={[0, -4, 0]}>
         <ArixParticles state={treeState} />
         <TopStar state={treeState} />
      </group>

      {/* Post Processing for the "Signature" Look */}
      <EffectComposer disableNormalPass>
        {/* Intense Bloom for the Gold and Lights */}
        <Bloom 
            luminanceThreshold={0.8} 
            mipmapBlur 
            intensity={1.5} 
            radius={0.4}
        />
        {/* Vignette to focus the eye */}
        <Vignette eskil={false} offset={0.1} darkness={1.1} />
        {/* Subtle Noise for film grain texture */}
        <Noise opacity={0.05} blendFunction={BlendFunction.OVERLAY} />
      </EffectComposer>
      
      {/* Fog for depth */}
      <fog attach="fog" args={['#050505', 10, 50]} />
      <color attach="background" args={['#050505']} />
    </Canvas>
  );
};
